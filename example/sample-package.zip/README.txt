Software:
om-annotsv-svc.jar

usage:
java -jar om-annotsv-svc.jar -b <bionano pipeline result file> -a <annotsv tsv file> -o <result.csv> [-g] [-r] [-d <Integer>] [-t <comma separated list>]

options:
 -a,--annotsv_input <arg>      annotsv tsv file path
 -b,--bionano_input <arg>      bionano pipeline result file path (smap)
 -d,--variant_distance <arg>   variants distance sum (start distance + end distance) filter
 -g,--gene_intersection        select only variants with common genes (default false)
 -o,--output <arg>             output result file
 -t,--variant_type <arg>       variant type filter, any combination of [BND,CNV,DEL,INS,DUP,INV,UNK]

Tomas Novosad, VSB-TU Ostrava, 2021
FEI, Department of Computer Science
Version: 1.0
License: GPL-3.0-only

Examples of running software:

*** Bionano-PacBio ***

** Original - annotated SVs after De Novo Assembly and Variant Annotation Pipeline. **
Original SVs: 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL.csv

Original SVs (50000 DST filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL_50000-DST.csv -d 50000

Original SVs (genes filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL_genes.csv -g

Original SVs (50000 DST and genes filters): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL_50000-DST_genes.csv -d 50000 -g


** BDHC - annotated SVs after De Novo Assembly and Variant Annotation Pipeline without SVs contained in Bionano Database of Healthy Controls. **
BDHC SVs: 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL.csv

BDHC SVs (50000 DST filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL_50000-DST.csv -d 50000

BDHC SVs (genes filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL_genes.csv -g

BDHC SVs (50000 DST and genes filters): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_PacBio_100_ALL_50000-DST_genes.csv -d 50000 -g


*** Bionano-ONT ***

** Original - annotated SVs after De Novo Assembly and Variant Annotation Pipeline. **
Original SVs: 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL.csv

Original SVs (50000 DST filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL_50000-DST.csv -d 50000

Original SVs (genes filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL_genes.csv -g

Original SVs (50000 DST and genes filters): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL_50000-DST_genes.csv -d 50000 -g

** BDHC - annotated SVs after De Novo Assembly and Variant Annotation Pipeline without SVs contained in Bionano Database of Healthy Controls. **
BDHC SVs: 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL.csv

BDHC SVs (50000 DST filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL_50000-DST.csv -d 50000

BDHC SVs (genes filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL_genes.csv -g

BDHC SVs (50000 DST and genes filters): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_ONT_100_ALL_50000-DST_genes.csv -d 50000 -g


*** Bionano-10X *** 

** Original - annotated SVs after De Novo Assembly and Variant Annotation Pipeline. **
Original SVs: 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL.csv

Original SVs (50000 DST filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL_50000-DST.csv -d 50000

Original SVs (genes filter): java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL_genes.csv -g

Original SVs (50000 DST and genes filters): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_100_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL_50000-DST_genes.csv -d 50000 -g

** BDHC - annotated SVs after De Novo Assembly and Variant Annotation Pipeline without SVs contained in Bionano Database of Healthy Controls. **
BDHC SVs: 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL.csv

BDHC SVs (50000 DST filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL_50000-DST.csv -d 50000

BDHC SVs (genes filter): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL_genes.csv -g

BDHC SVs (50000 DST and genes filters): 
java -jar om-annotsv-svc.jar -a ./WGS/SKBR3_10X_longranger_AnnotSV.tsv -b ./Bionano/Bionano_SKBR3-De_Novo_0_Canonical_mapped.smap -o ./SKBR3_10X_100_ALL_50000-DST_genes.csv -d 50000 -g