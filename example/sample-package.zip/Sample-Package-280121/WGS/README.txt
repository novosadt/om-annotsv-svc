SKBR3_PacBio_pbmm2_pbsv_AnnotSV.tsv - AnnotSV output of PacBio vcf results
SKBR3_ONT_pbmm2_pbsv_AnnotSV.tsv - AnnotSV output of ONT vcf results
SKBR3_10X_longranger_AnnotSV.tsv - AnnotSV output of 10X Genomics vcf results